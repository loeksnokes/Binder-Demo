# Binder-Demo
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/le27/Binder-Demo/master)


LoadPackage("packageManager");

InstallPackage("https://github.com/le27/aaa.git");

LoadPackage("aaa");

JupyterSplashDot(DotTransducer(RandomTransducer(2, 3)));
